package com.virtusa.Dao;

import java.sql.Connection;


import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.VenueBean;

public class BookingDao {
	
	 public static Connection getConnection(){  
	     
	        Logger log=Logger.getLogger(BookingDao.class);
	        PropertyConfigurator.configure("log4j.properties");
	        Connection con=null;  
	        try{  
	            Class.forName("oracle.jdbc.driver.OracleDriver");  
	            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
	          
	        }catch(Exception e)
	       { 
	        	log.error(e);
	         }  
	        return con;  
	    }  
	    public static int save(VenueBean e){  
	    	 Logger log=Logger.getLogger(BookingDao.class);
		        PropertyConfigurator.configure("log4j.properties");
		        
	    	
	        int status=0;  
	        try{  
	            Connection con=BookingDao.getConnection();  
	            try(PreparedStatement ps=con.prepareStatement("insert into bookvenue(venueId,venueName,venueCost,venueContact) values (?,?,?,?)")){	            ps.setInt(1,e.getVenueId());  
	            ps.setString(2,e.getVenueName());  
	            ps.setInt(3,e.getVenueCost());  
	            ps.setDouble(4,e.getVenueContact());  
	            
	            status=ps.executeUpdate();
	            
	            con.close();  
	        }
	        }catch(Exception ex){
	        	
	        	log.error(ex);
	        	}  
	         
	        return status;  
	    
	    }
	
	    
	    public static VenueBean getBookById(int venueId){  
	        VenueBean e=new VenueBean();  
	        Logger log=Logger.getLogger(BookingDao.class);
	        PropertyConfigurator.configure("log4j.properties");
	        
	     
	         try{  
	             Connection con=BookingDao.getConnection(); 
	             try(PreparedStatement ps=con.prepareStatement("select * from  viewmanagement where venueId=?")) {
	             ps.setInt(1,venueId);  
	             ResultSet rs=ps.executeQuery();  
	             if(rs.next()){  
	                 e.setVenueId(rs.getInt(1));  
	                 e.setVenueName(rs.getString(2));  
	                 e.setVenueCost(rs.getInt(3));  
	                 e.setVenueContact(rs.getInt(4));  
	                   
	             }  
	             con.close();  
	         }
	         }catch(Exception ex){
	        	 log.error(ex);
	        	 
	         }
	           
	         return e;  
	     }  
	  
	    
	    
	    
}
