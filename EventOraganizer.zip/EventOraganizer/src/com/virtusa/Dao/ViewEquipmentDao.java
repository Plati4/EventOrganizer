package com.virtusa.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.virtusa.bean.EquipBean;

public class ViewEquipmentDao {
	public static Connection getConnection(){  
	       Connection con=null;  
	       try{  
	           Class.forName("oracle.jdbc.driver.OracleDriver");  
	           con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
	       }catch(Exception e)
	      {
	  System.out.println(e);
	   }  
	       return con;  
	   }  
	public static List<EquipBean> getAllEquipments(){  
	       List<EquipBean> list=new ArrayList<EquipBean>();  
	         
	       try{  
	           Connection con=EquipDao1.getConnection();  
	           PreparedStatement ps=con.prepareStatement("select * from Equipmanagement");  
	           ResultSet rs=ps.executeQuery();  
	           while(rs.next()){  
	            EquipBean e=new EquipBean();  
	               e.setEquipId(rs.getInt(1));  
	               e.setEquipName(rs.getString(2));  
	               e.setEquipCost(rs.getInt(3));  
	                 
	               list.add(e);  
	           }  
	           con.close();  
	       }catch(Exception e){e.printStackTrace();}  
	         
	       return list;  
	   }  
	 
	}
