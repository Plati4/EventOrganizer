package com.virtusa.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.bean.VenueBean;

public class ViewVenueDao {
	static final Logger logger = Logger.getLogger(ViewVenueDao.class);
	
	public static Connection getConnection(){  
		PropertyConfigurator.configure("C:\\Users\\bhanu_000\\Desktop\\praticeprogs\\EventOraganizerHtml\\src\\log4j.properties");
        Connection con=null;  
        try{  
            Class.forName("oracle.jdbc.driver.OracleDriver");  
            con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","kavitha");  
        }catch(Exception e)
       {
  logger.error(e);
    }  
        return con;  
    }  

    public static List<VenueBean> getAllVenues(){  
        List<VenueBean> list=new ArrayList<VenueBean>();  
          
        try{  
            Connection con=VenueDao.getConnection();  
            PreparedStatement ps=con.prepareStatement("select * from viewmanagement");  
            ResultSet rs=ps.executeQuery();  
            while(rs.next()){  
               VenueBean e=new VenueBean();  
                e.setVenueId(rs.getInt(1));  
                e.setVenueName(rs.getString(2));  
                e.setVenueCost(rs.getInt(3));  
                e.setVenueContact(rs.getInt(4));    
                list.add(e);  
            }  
            con.close();  
        }catch(Exception e){e.printStackTrace();}  
          
        return list;  
    }  
}
