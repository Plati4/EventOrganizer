package com.virtusa.Service;

import java.util.List;

import com.virtusa.Dao.EquipDao1;
import com.virtusa.bean.EquipBean;

public class EquipService {
	public int equipSave(EquipBean e) {
		// TODO Auto-generated method stub
		int s=EquipDao1.save(e);
		return s;
	}
	public List<EquipBean> equipVenue() {
		// TODO Auto-generated method stub
		List<EquipBean> list1=	EquipDao1.getAllEquipments();
		return list1;
	}
	public EquipBean editEquip(int id) {
		// TODO Auto-generated method stub
		EquipBean e=EquipDao1.getequipById(id);
		return e;
	}
	public int editEquip2(EquipBean e) {
		
		int s=EquipDao1.update(e);
		return s;
	}
	public void equipDelete(int equipId) {
		// TODO Auto-generated method stub
		EquipDao1.delete(equipId);
		
	}
	

}
