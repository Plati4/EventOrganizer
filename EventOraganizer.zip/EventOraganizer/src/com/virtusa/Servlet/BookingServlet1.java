
package com.virtusa.Servlet;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.virtusa.bean.*;
import com.virtusa.Dao.*;
import java.io.PrintWriter;  
@WebServlet("/BookingServlet1")  
public class  BookingServlet1 extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   
          throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
        String sid=request.getParameter("venueId");  
        int id=Integer.parseInt(sid);  
        String name=request.getParameter("venueName");  
        
       String scost=request.getParameter("venueCost"); 
        int cost=Integer.parseInt(scost); 
         String scontact=request.getParameter("venueContact");  
        int contact=Integer.parseInt(scontact); 
        
      VenueBean e=new VenueBean();  
        e.setVenueId(id);  
        e.setVenueName(name);  
        e.setVenueCost(cost);  
        e.setVenueContact(contact);  
         
          
        int status=BookingDao.save(e);  
        if(status>0){  

        	  out.println(" record  booked"); 
        }else{  
            out.println("Sorry! unable to book record");  
        }  
          
        out.close();  
    }  
  
}  
