package com.virtusa.Servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.bean.VenueBean;
import com.virtusa.Dao.VenueDao;
import com.virtusa.Service.VenueService;

import java.io.PrintWriter;  
  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  
@WebServlet("/EditServlet2")  
public class EditVenue2 extends HttpServlet {  
    protected void doPost(HttpServletRequest request, HttpServletResponse response)   
          throws ServletException, IOException {  
        response.setContentType("text/html");  
        PrintWriter out=response.getWriter();  
          
        String sid=request.getParameter("venueId");  
        int id=Integer.parseInt(sid);  
        String name=request.getParameter("venueName");  
       String scost=request.getParameter("venueCost"); 
        int cost=Integer.parseInt(scost); 
         String scontact=request.getParameter("venueContact");  
        int contact=Integer.parseInt(scontact); 
        
      VenueBean e=new VenueBean();  
        e.setVenueId(id);  
        e.setVenueName(name);  
        e.setVenueCost(cost);  
        e.setVenueContact(contact);    

        VenueService ob=new VenueService();
        int status=ob.editVenue2(e);
        
        if(status>0){  
            response.sendRedirect("ViewServlet");  
        }else{  
            out.println("Sorry! unable to update record");  
        }  
          
        out.close();  
    }  
  
}  