package com.virtusa.Servlet;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.virtusa.Dao.BookingDao;
import com.virtusa.Dao.LoginDao;

@WebServlet("/login")
public class Login extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
	        throws ServletException, IOException {  
		
	 
	    response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	          
	    String n=request.getParameter("uname");  
	    String p=request.getParameter("pword");
	    HttpSession se = request.getSession();
	    se.setAttribute("username", n);
	    if(LoginDao.validate(n, p)){  
	    	out.print("login success...");
	        RequestDispatcher rd=request.getRequestDispatcher("WelcomeAdmin.jsp");  
	        rd.forward(request,response);  
	    }  
	    else{  
	        out.print("Sorry username or password error");  
	        RequestDispatcher rd=request.getRequestDispatcher("Admin.html");  
	        rd.include(request,response);  
	    }  
	          
	    out.close();  
	    }  
	}  
