
package com.virtusa.Servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.bean.FoodBean;
import com.virtusa.Dao.FoodDao;
import com.virtusa.Service.FoodService;


@WebServlet("/SaveFood")
public class SaveFood extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
			response.setContentType("text/html");
			PrintWriter out=response.getWriter();
			
			
			String sid1=request.getParameter("foodId");
			int id=Integer.parseInt(sid1); 
			String sn=request.getParameter("foodName");
			String sc=request.getParameter("foodCost");
			 int scost1=Integer.parseInt(sc); 
			
			FoodBean e=new FoodBean();
			
			e.setFoodId(id);
			e.setFoodName(sn);
			e.setFoodCost(scost1);
			

			FoodService ob=new FoodService();
			int status=ob.saveFood(e);
			if(status>0){
				out.print("<p>Record saved successfully!</p>");
				request.getRequestDispatcher("foodManagement.html").include(request, response);
			}else{
				out.println("Sorry! unable to save record");
			}
			
			out.close();
		}

	}
	