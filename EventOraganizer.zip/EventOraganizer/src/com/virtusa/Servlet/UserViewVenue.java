package com.virtusa.Servlet;
import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.List;  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;

import com.virtusa.bean.EquipBean;
import com.virtusa.bean.FoodBean;
import com.virtusa.bean.VenueBean;
import com.virtusa.Dao.*;
@WebServlet("/ViewServlet1")
public class UserViewVenue extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.println("<h1>venues  List</h1>");
		List<VenueBean> list=ViewVenueDao.getAllVenues();
		List<FoodBean> list1=ViewFoodDao.getAllFood();
		List<EquipBean> list2=ViewEquipmentDao.getAllEquipments();
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>Id</th><th>venueName</th><th>venuecost</th><th>venuecontact</th><th>Book</th>");
		
		for(VenueBean e:list){
			out.print("<tr><td>"+e.getVenueId()+"</td><td>"+e.getVenueName()+"</td><td>"+e.getVenueCost()+"</td><td>"+e.getVenueContact()+"</td></td><td><a href='BookingServlet?id="+e.getVenueId()+"'>BookVenue</a></td></tr>");
		}
		out.print("</table>");
		
		out.println("<h1>Foods List</h1>");
 		
 		
 		out.print("<table border='1' width='100%'");
 		out.print("<tr><th>foodId</th><th>foodName</th><th>foodCost</th><th>Book</th></tr>");
 		for(FoodBean e:list1){
 			out.print("<tr><td>"+e.getFoodId()+"</td><td>"+e.getFoodName()+"</td><td>"+e.getFoodCost()+"</td><td><a href='BookingFood?id="+e.getFoodId()+"'>BookFood</td></tr>");
 		}
 		out.print("</table>");
 		
 		out.println("<h1>equipments List</h1>");

 		
 		out.print("<table border='1' width='100%'");
 		out.print("<tr><th>Id</th><th>equipName</th><th>equipcost</th><th>BookEquipment</th><th></tr>");
 		for(EquipBean e:list2){
 		out.print("<tr><td>"+e.getEquipId()+"</td><td>"+e.getEquipName()+"</td><td>"+e.getEquipCost()+"</td><td><a href='BookingEquipment?id="+e.getEquipId()+"'>BookEquipment</td></tr>");
 		}
 		out.print("</table>");

 
		
				
		out.close();
	}
}