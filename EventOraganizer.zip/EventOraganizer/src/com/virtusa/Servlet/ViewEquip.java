 package com.virtusa.Servlet;
import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.List;  
 
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;

import com.virtusa.bean.EquipBean;
import com.virtusa.Service.EquipService;
@WebServlet("/ViewEquip")
public class ViewEquip extends HttpServlet {
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
PrintWriter out=response.getWriter();
out.println("<a href='Equipment.html'>Add New Equipment</a>");
out.println("<h1>equipments List</h1>");


EquipService ob=new EquipService();
List<EquipBean> list=ob.equipVenue();
out.print("<table border='1' width='100%'");
out.print("<tr><th>Id</th><th>equipName</th><th>equipcost</th><th>Edit</th><th>Delete</th></tr>");
for(EquipBean e:list){
out.print("<tr><td>"+e.getEquipId()+"</td><td>"+e.getEquipName()+"</td><td>"+e.getEquipCost()+"</td><td><a href='EditEquip?id="+e.getEquipId()+"'>edit</a></td><td><a href='DeleteEquip?id="+e.getEquipId()+"'>delete</a></td></tr>");
}
out.print("</table>");

out.close();
}
}