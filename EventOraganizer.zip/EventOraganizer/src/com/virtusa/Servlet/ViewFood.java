 package com.virtusa.Servlet;
import java.io.IOException;  

import java.io.PrintWriter;  
import java.util.List;  
  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;

import com.virtusa.bean.FoodBean;
import com.virtusa.Dao.FoodDao;
import com.virtusa.Service.FoodService;


@WebServlet("/ViewFood")
public class ViewFood extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='foodManagement.html'>Add New Food</a>");
		out.println("<h1>Foods  List</h1>");
		
		
		FoodService ob=new FoodService();
		List<FoodBean> list=ob.viewFood();
		
		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>foodId</th><th>foodName</th><th>foodCost</th><th>Edit</th><th>Delete</th></tr>");
		for(FoodBean e:list){
			out.print("<tr><td>"+e.getFoodId()+"</td><td>"+e.getFoodName()+"</td><td>"+e.getFoodCost()+"</td><td><a href='EditFood?id="+e.getFoodId()+"'>edit</a></td><td><a href='DeleteFood?id="+e.getFoodId()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}