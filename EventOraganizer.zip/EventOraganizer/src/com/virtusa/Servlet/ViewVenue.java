
 package com.virtusa.Servlet;
import java.io.IOException;  
import java.io.PrintWriter;  
import java.util.List;  
  
import javax.servlet.ServletException;  
import javax.servlet.annotation.WebServlet;  
import javax.servlet.http.HttpServlet;  
import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.virtusa.bean.VenueBean;
import com.virtusa.Dao.BookingEquipmentDao;
import com.virtusa.Service.VenueService;


@WebServlet("/ViewServlet")
public class ViewVenue extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		out.println("<a href='viewManagement.html'>Add New venue</a>");
		out.println("<h1>venues  List</h1>");
		

		VenueService ob=new VenueService();
		List<VenueBean> list=ob.viewvenue();		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>Id</th><th>venueName</th><th>venuecost</th><th>venuecontact</th><th>Edit</th><th>Delete</th></tr>");
		for(VenueBean e:list){
			out.print("<tr><td>"+e.getVenueId()+"</td><td>"+e.getVenueName()+"</td><td>"+e.getVenueCost()+"</td><td>"+e.getVenueContact()+"</td><td><a href='EditServlet?id="+e.getVenueId()+"'>edit</a></td><td><a href='DeleteServlet?id="+e.getVenueId()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}